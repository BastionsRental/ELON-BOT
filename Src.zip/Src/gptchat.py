from flask import Flask, request, jsonify
from flask_cors import CORS, cross_origin
import whisper
import os
import requests
import openai
import base64

openai.api_key = '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'

app = Flask(__name__)

model = whisper.load_model("small")
CORS(app, resources={r"/*": {"origins": "*"}})


@app.route('/transcribe', methods=['POST'])
@cross_origin()
def transcribe_audio():
    if 'audio' not in request.files:
        return 'No audio file in request', 400

    audio_file = request.files['audio']

    # Define a directory path to save the audio files
    save_path = "./Audio/"

    # Use the current timestamp to create a unique file name for each audio file
    file_name = "prompt.mp3"

    # Save the audio file
    audio_file.save(os.path.join(save_path, file_name))

    result = model.transcribe(os.path.join(save_path, file_name))
    transcription = result["text"]

    return transcription


chat = [{'question': "I want you to channel your inner Tony Stark from the Marvel Universe. I want your responses and answers to embody the charismatic, witty, and genius persona of Stark, using the tone, manner and vocabulary he would use. No need for explanatory notes. Just respond in pure Stark style. You must have a comprehensive understanding of Tony Stark's character traits. My first sentence is, “Hi Tony.”", 'answer': "Greetings, my friend. It's always a pleasure to hear from another genius such as myself. How can I assist you today?"}]


@app.route('/ask_question', methods=['POST'])
def ask_question():

    question = request.json.get('question', '')
    if not question:
        return jsonify({'error': 'No question provided'}), 400

    chat_log = [{"role": "system", "content": "You are Tony Stark"},
                {"role": "user", "content": question}]

    gptresponse = openai.ChatCompletion.create(
        model="text-davinci-003",
        messages=chat_log,
    )

    chat.append({"question": question, "answer": gptresponse['choices'][0]['message']['content']})

    CHUNK_SIZE = 1024
    url = "https://api.elevenlabs.io/v1/text-to-speech/I4BiQB0HqUz18tjI4kWN"

    headers = {
        "Accept": "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": "64ee4a7a93207433056d89df8dd6c462"
    }

    data = {
        "text": gptresponse['choices'][0]['message']['content'],
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.5
        }
    }

    response = requests.post(url, json=data, headers=headers)
    with open('./Audio/output.mp3', 'wb') as f:
        for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
            if chunk:
                f.write(chunk)

    # Encode the audio file as base64
    with open('./Audio/output.mp3', 'rb') as audio_file:
        audio_base64bytes = base64.b64encode(audio_file.read())
        audio_base64string = audio_base64bytes.decode('utf-8')

    return jsonify({'answer': gptresponse['choices'][0]['message']['content'], 'audio': audio_base64string})

if __name__ == '__main__':
    app.run(port=5300, debug=True)
